<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

// 1. หน้า Login
Route::get('/login', function () {
    return view('auth.login');
})->name('login');

Route::post('/login', function (Request $request) {
    $credentials = $request->validate([
        'email' => ['required', 'email'],
        'password' => ['required'],
    ]);

    if (Auth::attempt($credentials)) {
        $request->session()->regenerate();
        return redirect()->intended('/dashboard');
    }

    return back()->withErrors(['email' => 'อีเมลหรือรหัสผ่านไม่ถูกต้อง']);
});

Route::post('/logout', function (Request $request) {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    return redirect('/login');
})->name('logout');

// 2. หน้า Dashboard & Report
Route::get('/dashboard', function () {
    $totalSales = DB::table('orders')->sum('total_amount') ?? 0;
    $todaySales = DB::table('orders')->whereDate('created_at', today())->sum('total_amount') ?? 0;
    $productCount = Product::count();
    $employeeCount = User::count();
    $recentOrders = DB::table('orders')->latest()->take(5)->get();

    return view('dashboard', compact('totalSales', 'todaySales', 'productCount', 'employeeCount', 'recentOrders'));
})->middleware('auth')->name('dashboard');

// 3. โมดูลพนักงาน
Route::get('/employees', function () {
    $employees = User::all();
    return view('employees.index', compact('employees'));
})->middleware('auth')->name('employees.index');

Route::get('/pos', function () {
    $products = Product::all();
    return view('pos.index', compact('products'));
})->middleware('auth')->name('pos.index');