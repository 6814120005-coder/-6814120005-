<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\Member;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        Product::create(['name' => 'Espresso', 'price' => 55, 'stock_qty' => 20]);
        Product::create(['name' => 'Iced Latte', 'price' => 65, 'stock_qty' => 15]);
        Product::create(['name' => 'Green Tea', 'price' => 60, 'stock_qty' => 10]);
        
        Member::create(['name' => 'John Doe', 'phone' => '0812345678', 'points' => 0]);
    }
}