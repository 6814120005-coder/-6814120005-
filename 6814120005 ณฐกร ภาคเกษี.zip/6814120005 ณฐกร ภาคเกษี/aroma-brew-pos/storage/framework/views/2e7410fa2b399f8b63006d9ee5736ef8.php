<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Aroma Brew POS</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-6xl mx-auto">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold text-amber-900">📊 Dashboard & รายงานการขาย</h1>
            <div class="flex gap-3">
                <a href="/pos" class="bg-amber-600 text-white px-4 py-2 rounded shadow hover:bg-amber-700">🛒 ไปหน้า POS</a>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">ออกจากระบบ</button>
                </form>
            </div>
        </div>

        <!-- การ์ดสรุปข้อมูล -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white p-5 rounded-lg shadow border-l-4 border-green-500">
                <p class="text-sm text-gray-500">ยอดขายรวมวันนี้</p>
                <p class="text-2xl font-bold text-gray-800">฿<?php echo e(number_format($todaySales, 2)); ?></p>
            </div>
            <div class="bg-white p-5 rounded-lg shadow border-l-4 border-blue-500">
                <p class="text-sm text-gray-500">ยอดขายรวมทั้งหมด</p>
                <p class="text-2xl font-bold text-gray-800">฿<?php echo e(number_format($totalSales, 2)); ?></p>
            </div>
            <div class="bg-white p-5 rounded-lg shadow border-l-4 border-amber-500">
                <p class="text-sm text-gray-500">จำนวนสินค้าในระบบ</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo e($productCount); ?> รายการ</p>
            </div>
            <div class="bg-white p-5 rounded-lg shadow border-l-4 border-purple-500">
                <p class="text-sm text-gray-500">จำนวนพนักงาน</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo e($employeeCount); ?> คน</p>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\Vegas\Desktop\6814120005 ณฐกร ภาคเกษี\aroma-brew-pos\resources\views/dashboard.blade.php ENDPATH**/ ?>