<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เข้าสู่ระบบ - Aroma Brew POS</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h2 class="text-2xl font-bold text-center text-amber-800 mb-6">☕ Aroma Brew POS</h2>
        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-600 p-2 rounded mb-4 text-sm">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" name="email" required class="w-full mt-1 p-2 border rounded-md focus:ring-amber-500 focus:border-amber-500">
            </div>
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700">Password</label>
                <input type="password" name="password" required class="w-full mt-1 p-2 border rounded-md focus:ring-amber-500 focus:border-amber-500">
            </div>
            <button type="submit" class="w-full bg-amber-600 text-white py-2 rounded-md hover:bg-amber-700">เข้าสู่ระบบ</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\Vegas\Desktop\6814120005 ณฐกร ภาคเกษี\aroma-brew-pos\resources\views/auth/login.blade.php ENDPATH**/ ?>