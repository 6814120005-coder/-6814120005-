<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Aroma Brew - POS System</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow">
        <h1 class="text-2xl font-bold text-amber-800 mb-4">☕ Aroma Brew - ระบบขายหน้าร้าน (POS)</h1>
        <p class="text-gray-600 mb-4">ยินดีต้อนรับเข้าสู่ระบบจัดการการขายสินค้า</p>
        <!-- แสดงรายการสินค้าหรือตะกร้าสินค้า -->
    </div>
</body>
</html><?php /**PATH C:\Users\Vegas\Desktop\6814120005 ณฐกร ภาคเกษี\aroma-brew-pos\resources\views/pos/index.blade.php ENDPATH**/ ?>