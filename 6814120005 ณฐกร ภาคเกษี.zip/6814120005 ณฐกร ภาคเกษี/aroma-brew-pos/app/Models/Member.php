<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;

    // เพิ่มบรรทัดนี้เข้าไปเช่นกัน
    protected $fillable = ['name', 'phone', 'points'];
}