<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Member;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class PosController extends Controller
{
    // หน้าจอขายสินค้า POS
    public function index()
    {
        $products = Product::where('stock_qty', '>', 0)->get();
        $members = Member::all();
        return view('pos.index', compact('products', 'members'));
    }

    // ประมวลผลการขาย จ่ายเงิน และตัดสต็อก (Sale & Payment Module)
    public function store(Request $request)
    {
        $request->validate([
            'items' => 'required|array',
            'payment_method' => 'required|in:cash,promptpay',
        ]);

        return DB::transaction(function () use ($request) {
            // 1. คำนวณยอดเงิน
            $subtotal = 0;
            foreach ($request->items as $item) {
                $subtotal += $item['price'] * $item['qty'];
            }
            $vat = $subtotal * 0.07;
            $totalAmount = $subtotal + $vat;

            // 2. สะสมแต้มสมาชิก (ซื้อครบ 50 บาท = 1 แต้ม)
            $pointsEarned = floor($totalAmount / 50);

            // 3. บันทึกออเดอร์
            $order = Order::create([
                'order_no' => 'INV-' . time(),
                'user_id' => Auth::id() ?? 1,
                'member_id' => $request->member_id,
                'subtotal' => $subtotal,
                'vat' => $vat,
                'total_amount' => $totalAmount,
                'payment_method' => $request->payment_method,
                'points_earned' => $pointsEarned,
            ]);

            // 4. บันทึกรายการสินค้า + ตัดสต็อกสินค้าอัตโนมัติ (Stock Module Integration)
            foreach ($request->items as $item) {
                $order->items()->create([
                    'product_id' => $item['id'],
                    'sweetness' => $item['sweetness'] ?? '100%',
                    'type' => $item['type'] ?? 'Hot',
                    'quantity' => $item['qty'],
                    'price' => $item['price'],
                ]);

                // ตัดสต็อก
                Product::where('id', $item['id'])->decrement('stock_qty', $item['qty']);
            }

            // 5. อัปเดตแต้มสมาชิก
            if ($request->member_id) {
                Member::where('id', $request->member_id)->increment('points', $pointsEarned);
            }

            return response()->json([
                'success' => true,
                'message' => 'บันทึกการขายสำเร็จ',
                'order_id' => $order->id,
                'order_no' => $order->order_no
            ]);
        });
    }
}